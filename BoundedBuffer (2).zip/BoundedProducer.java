class BoundedProducer implements Runnable {
    private BoundedBuffer buffer;

    public BoundedProducer(BoundedBuffer buffer) {
        this.buffer = buffer;
    }

    @Override
    public void run() {
        try {
            for (int i = 1; i <= 20; i++) {
                buffer.produce(i);  // Produce item and add to buffer
                Thread.sleep(500);  // Simulate delay
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}

class BoundedConsumer implements Runnable {
    private BoundedBuffer buffer;

    public BoundedConsumer(BoundedBuffer buffer) {
        this.buffer = buffer;
    }

    @Override
    public void run() {
        try {
            for (int i = 1; i <= 20; i++) {
                buffer.consume();  // Consume item from buffer
                Thread.sleep(1000);  // Simulate delay
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
