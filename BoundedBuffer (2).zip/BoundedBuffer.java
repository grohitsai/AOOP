import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ArrayBlockingQueue;

class BoundedBuffer {
    private final BlockingQueue<Integer> queue;

    public BoundedBuffer(int capacity) {
        this.queue = new ArrayBlockingQueue<>(capacity); // Bounded buffer with fixed capacity
    }

    // Produce item and put it in the queue
    public void produce(int item) throws InterruptedException {
        queue.put(item);  // Wait if the buffer is full
        System.out.println("Produced: " + item);
    }

    // Consume item from the queue
    public int consume() throws InterruptedException {
        int item = queue.take();  // Wait if the buffer is empty
        System.out.println("Consumed: " + item);
        return item;
    }
}
