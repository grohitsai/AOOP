public class BoundedBufferApp {
    public static void main(String[] args) {
        BoundedBuffer buffer = new BoundedBuffer(10);  // Create buffer with capacity 10

        BoundedProducer producer = new BoundedProducer(buffer);
        BoundedConsumer consumer = new BoundedConsumer(buffer);

        // Create and start producer and consumer threads
        Thread producerThread = new Thread(producer);
        Thread consumerThread = new Thread(consumer);

        producerThread.start();
        consumerThread.start();
    }
}
