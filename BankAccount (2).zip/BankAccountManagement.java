public class BankAccountManagement {
    public static void main(String[] args) {
        BankAccount sharedAccount = new BankAccount(1000); // Initialize with a balance of 1000

        // Create multiple threads representing different users
        Thread user1 = new Thread(new BankUser(sharedAccount), "User1");
        Thread user2 = new Thread(new BankUser(sharedAccount), "User2");
        Thread user3 = new Thread(new BankUser(sharedAccount), "User3");

        // Start the threads
        user1.start();
        user2.start();
        user3.start();

        // Ensure all threads finish execution
        try {
            user1.join();
            user2.join();
            user3.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Final balance
        System.out.println("Final balance: " + sharedAccount.getBalance());
    }
}
