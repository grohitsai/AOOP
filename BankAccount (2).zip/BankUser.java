class BankUser implements Runnable {
    private BankAccount account;

    // Constructor to link a user to a specific bank account
    public BankUser(BankAccount account) {
        this.account = account;
    }

    @Override
    public void run() {
        // Simulate multiple operations by each user
        for (int i = 0; i < 5; i++) {
            double amount = Math.random() * 100; // Generate a random amount between 0 and 100

            // Randomly choose whether to deposit or withdraw
            if (Math.random() > 0.5) {
                account.deposit(amount);
            } else {
                account.withdraw(amount);
            }

            // Display the balance after each transaction
            System.out.println(Thread.currentThread().getName() + " balance after transaction: " + account.getBalance());

            try {
                Thread.sleep(100); // Simulate some delay between operations
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
