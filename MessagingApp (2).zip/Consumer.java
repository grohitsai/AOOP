import java.util.concurrent.BlockingQueue;

class Consumer implements Runnable {
    private BlockingQueue<String> queue;

    public Consumer(BlockingQueue<String> queue) {
        this.queue = queue;
    }

    @Override
    public void run() {
        try {
            String message;
            while (!(message = queue.take()).equals("END")) { // Take message from the queue
                System.out.println("Consumed: " + message);
                Thread.sleep(1000); // Simulate delay
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
