import java.util.concurrent.BlockingQueue;

class Producer implements Runnable {
    private BlockingQueue<String> queue;

    public Producer(BlockingQueue<String> queue) {
        this.queue = queue;
    }

    @Override
    public void run() {
        try {
            for (int i = 1; i <= 10; i++) {
                String message = "Message " + i;
                queue.put(message); // Add message to the queue
                System.out.println("Produced: " + message);
                Thread.sleep(500); // Simulate delay
            }
            queue.put("END"); // Special message to indicate end of messages
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
